# APS-Basic-6A
This is the repository for the 6th APSignals Basic Bootcamp
